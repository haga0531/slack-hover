// Slack DOM Parser and Observer

const SELECTORS = {
  MESSAGE_CONTAINER: '.c-virtual_list__item[data-item-key]',
  MESSAGE_TEXT: '[data-qa="message-text"]',
  MESSAGE_CONTENT: '.c-message_kit__message',
  SCROLL_CONTAINER: '.c-virtual_list__scroll_container',
  WORKSPACE_VIEW: '.p-workspace__primary_view_contents',
  MESSAGE_ACTIONS: '.c-message__actions',
};

const SlackDOMParser = {
  // Parse Slack URL to extract team_id, channel_id, and thread_ts
  parseSlackUrl() {
    const url = window.location.href;

    // Pattern 1: Thread view
    // https://app.slack.com/client/T123/C456/thread/C456-1234567890.123456
    const threadPattern = /\/client\/([^\/]+)\/([^\/]+)\/thread\/([^-]+)-(.+)/;

    // Pattern 2: Channel view
    // https://app.slack.com/client/T123/C456
    const channelPattern = /\/client\/([^\/]+)\/([^\/]+)/;

    let match = url.match(threadPattern);
    if (match) {
      return {
        teamId: match[1],
        channelId: match[2],
        threadChannelId: match[3],
        threadTs: match[4],
      };
    }

    match = url.match(channelPattern);
    if (match) {
      return {
        teamId: match[1],
        channelId: match[2],
        threadTs: null,
      };
    }

    return null;
  },

  // Extract message metadata from DOM element
  extractMessageMetadata(messageElement) {
    const urlData = this.parseSlackUrl();

    if (!urlData) {
      return null;
    }

    // Try to get thread_ts from data-item-key
    const itemKey = messageElement.getAttribute("data-item-key");

    // The item key format varies, try to extract timestamp
    let messageTs = null;
    if (itemKey) {
      // itemKey might be in format like "1234567890.123456" or include prefix
      const tsMatch = itemKey.match(/(\d+\.\d+)/);
      if (tsMatch) {
        messageTs = tsMatch[1];
      }
    }

    return {
      teamId: urlData.teamId,
      channelId: urlData.channelId,
      threadTs: urlData.threadTs || messageTs,
      messageTs: messageTs,
    };
  },

  // Get all message elements
  getAllMessages() {
    return document.querySelectorAll(SELECTORS.MESSAGE_CONTAINER);
  },

  // Check if an element is actually a message (not a channel header or other item)
  isValidMessage(element) {
    // Must have a data-item-key with timestamp format (e.g., "1234567890.123456")
    const itemKey = element.getAttribute("data-item-key");
    if (!itemKey) return false;

    // Check if itemKey contains a valid Slack timestamp
    const hasTimestamp = /\d+\.\d+/.test(itemKey);
    if (!hasTimestamp) return false;

    // Must contain actual message content
    const hasMessageContent = element.querySelector(SELECTORS.MESSAGE_CONTENT) !== null;

    return hasMessageContent;
  },

  // Get thread reply count from DOM (returns null if not visible or not a thread)
  getReplyCount(messageElement) {
    const threadIndicator = messageElement.querySelector(
      '[data-qa="message_thread_reply_count"]'
    );
    if (!threadIndicator) {
      return null;
    }

    // Try to extract number from text like "5 replies" or "3件の返信"
    const text = threadIndicator.textContent || "";
    const match = text.match(/(\d+)/);
    return match ? parseInt(match[1], 10) : null;
  },
};

// Message Observer using MutationObserver + Periodic Scan
class SlackMessageObserver {
  constructor(callbacks) {
    this.callbacks = callbacks;
    this.observer = null;
    this.scanInterval = null;
    this.processedKeys = new Set(); // Track by data-item-key instead of WeakSet
  }

  start() {
    // Start mutation observer
    this.startMutationObserver();

    // Start periodic scan as fallback (every 1 second)
    this.scanInterval = setInterval(() => {
      this.scanForNewMessages();
    }, 1000);

    // Also scan on scroll (debounced)
    this.setupScrollListener();
  }

  startMutationObserver() {
    this.waitForContainer().then((container) => {
      this.observer = new MutationObserver((mutations) => {
        this.handleMutations(mutations);
      });

      this.observer.observe(container, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['data-item-key'],
      });

      // Process existing messages
      this.scanForNewMessages();
    });
  }

  setupScrollListener() {
    let scrollTimeout = null;

    const handleScroll = () => {
      if (scrollTimeout) clearTimeout(scrollTimeout);
      scrollTimeout = setTimeout(() => {
        this.scanForNewMessages();
      }, 200);
    };

    // Watch for scroll containers being added
    const attachScrollListener = () => {
      const containers = document.querySelectorAll(SELECTORS.SCROLL_CONTAINER);
      containers.forEach(container => {
        if (!container.dataset.stmScrollAttached) {
          container.dataset.stmScrollAttached = 'true';
          container.addEventListener('scroll', handleScroll, { passive: true });
        }
      });
    };

    // Initial attachment
    attachScrollListener();

    // Re-attach when DOM changes (for SPA navigation)
    const bodyObserver = new MutationObserver(() => {
      attachScrollListener();
    });
    bodyObserver.observe(document.body, { childList: true, subtree: true });
  }

  async waitForContainer() {
    return new Promise((resolve) => {
      const check = () => {
        const container = document.querySelector(SELECTORS.SCROLL_CONTAINER);
        if (container) {
          resolve(container);
        } else {
          setTimeout(check, 500);
        }
      };
      check();
    });
  }

  handleMutations(mutations) {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType === Node.ELEMENT_NODE) {
          this.processNode(node);
        }
      }
    }
  }

  processNode(node) {
    // Check if this node is a message container
    if (node.matches && node.matches(SELECTORS.MESSAGE_CONTAINER)) {
      this.processMessage(node);
    }

    // Check child elements
    const messages = node.querySelectorAll
      ? node.querySelectorAll(SELECTORS.MESSAGE_CONTAINER)
      : [];
    messages.forEach((msg) => this.processMessage(msg));
  }

  processMessage(messageElement) {
    const itemKey = messageElement.getAttribute('data-item-key');
    if (!itemKey) return;

    // Skip if already processed
    if (this.processedKeys.has(itemKey)) return;

    // Only process valid messages (not channel headers or other items)
    if (!SlackDOMParser.isValidMessage(messageElement)) return;

    // Mark as processed
    this.processedKeys.add(itemKey);

    if (this.callbacks.onNewMessage) {
      this.callbacks.onNewMessage(messageElement);
    }
  }

  scanForNewMessages() {
    const messages = SlackDOMParser.getAllMessages();
    messages.forEach((msg) => this.processMessage(msg));
  }

  stop() {
    if (this.observer) {
      this.observer.disconnect();
    }
    if (this.scanInterval) {
      clearInterval(this.scanInterval);
    }
  }
}

// Make available globally
window.SlackDOMParser = SlackDOMParser;
window.SlackMessageObserver = SlackMessageObserver;
